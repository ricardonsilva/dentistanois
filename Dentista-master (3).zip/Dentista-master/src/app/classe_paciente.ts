export class Classe_Paciente {
    prontuario: number;
    name: string;
    telefone: number;
    email: string;
  }