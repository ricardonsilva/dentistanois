import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { error } from 'protractor';
import { AuthService } from 'app/services/oauth.service';
import { UsuarioService } from 'app/services/usuario.service';
import { CredenciaisDTO } from 'app/models/credenciais.dto';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {




  //coisas que já estavam no codigo, verificar se precisa
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';

  //fim das coisas que já estavam no código, validar se precisa

  //DTO - Data transfer object
  //https://pt.stackoverflow.com/questions/31362/o-que-%C3%A9-um-dto/31365#31365
  credenciais: CredenciaisDTO = {
    email: '',
    password: ''
  };

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private usuarioService: UsuarioService
  ) {

  }

  //roda ao carregar a página e valida se o elemento já está autenticado
  ngOnInit() {
    if (this.authService.isAgenciaAuthenticated()) {
      this.router.navigate(['agencia']);
    }
    if (this.authService.isHotelAuthenticated()) {
      this.router.navigate(['hotel']);
    }
  }

//botao login
  login() {
    this.authService.authenticate(this.credenciais)
      .subscribe(response => {
        this.authService.successfullAuthenticationToken(response);
        this.goCurrentUsuario();
      },
      error => {
        console.log('Erro ao realizar o login agencia.');
      });
  }


  
  private goCurrentUsuario() {
    this.usuarioService.getCurrent()
      .subscribe(usuario => {
        this.authService.successfullAuthenticationUsuario(usuario);
        switch (usuario.tipo) {
          case 'AGENT':
            this.router.navigate(['dashboard']);
            break;
          default:
            console.log('tipo de usuario invalido encontrado ' + usuario.tipo);
            this.router.navigate(['login']);
            break;
        }
      });
  }

}
