import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaboratioriosComponent } from './laboratiorios.component';

describe('LaboratioriosComponent', () => {
  let component: LaboratioriosComponent;
  let fixture: ComponentFixture<LaboratioriosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaboratioriosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaboratioriosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
