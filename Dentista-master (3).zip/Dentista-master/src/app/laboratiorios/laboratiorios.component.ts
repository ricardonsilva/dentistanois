import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-laboratiorios',
  templateUrl: './laboratiorios.component.html',
  styleUrls: ['./laboratiorios.component.scss']
})
export class LaboratioriosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
