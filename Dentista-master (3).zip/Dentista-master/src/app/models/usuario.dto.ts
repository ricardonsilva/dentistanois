export interface UsuarioDTO {
    id: number;
    email: string;
    tipo: string;
}
