export interface CredenciaisDTO {
    email: string;
    password: string;
}
