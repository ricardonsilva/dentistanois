import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminLayoutRoutes } from './admin-layout.routing';
import { DashboardComponent } from '../../dashboard/dashboard.component';
import { AgendaComponent } from "../../agenda/agenda.component";
import { PacientesComponent } from "../../pacientes/pacientes.component";
import { UserProfileComponent } from '../../user-profile/user-profile.component';
import { TableListComponent } from '../../table-list/table-list.component';
import { TypographyComponent } from '../../typography/typography.component';
import { IconsComponent } from '../../icons/icons.component';
import { NotificationsComponent } from '../../notifications/notifications.component';
import { FullCalendarModule } from "@fullcalendar/angular";
import { CadastroPacienteComponent } from "../../pacientes/cadastro-paciente/cadastro-paciente.component";
import { DeleteComponent } from "../../pacientes/delete/delete.component";
import { AgendarConsultaComponent } from "../../agenda/agendar-consulta/agendar-consulta.component";
import { ProntuarioComponent } from "../../pacientes/prontuario/prontuario.component";
import { AnamneseComponent } from "../../pacientes/prontuario/anamnese/anamnese.component";
import { AnotacoesComponent } from "../../pacientes/prontuario/anotacoes/anotacoes.component";
import { ConsultasComponent } from "../../pacientes/prontuario/consultas/consultas.component";
import { FinanceiroComponent } from "../../pacientes/prontuario/financeiro/financeiro.component";
import { HistoricoComponent } from "../../pacientes/prontuario/historico/historico.component";
import { ImagensComponent } from "../../pacientes/prontuario/imagens/imagens.component";
import { LaboratorioComponent } from "../../pacientes/prontuario/laboratorio/laboratorio.component";
import { ProcedimentosComponent } from "../../pacientes/prontuario/procedimentos/procedimentos.component";
import { ReceituarioComponent } from "../../pacientes/prontuario/receituario/receituario.component";
import { LaboratioriosComponent } from "../../laboratiorios/laboratiorios.component";

import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatFormFieldModule,
  MatPaginatorModule,
} from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    FullCalendarModule,  // for FullCalendar!
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatPaginatorModule,
  ],
  declarations: [
    DashboardComponent,
    AgendaComponent,
    PacientesComponent,
    UserProfileComponent,
    TableListComponent,
    TypographyComponent,
    IconsComponent,
    NotificationsComponent,
    CadastroPacienteComponent,
    DeleteComponent,
    AgendarConsultaComponent,
    ProntuarioComponent,
    AnamneseComponent,
    AnotacoesComponent,
    ConsultasComponent,
    FinanceiroComponent,
    HistoricoComponent,
    ImagensComponent,
    LaboratorioComponent,
    ProcedimentosComponent,
    ReceituarioComponent,
    LaboratioriosComponent
  ],
  entryComponents: [
    AgendarConsultaComponent,
    CadastroPacienteComponent,
    DeleteComponent,
    ProntuarioComponent,
    AnamneseComponent,
    AnotacoesComponent,
    ConsultasComponent,
    FinanceiroComponent,
    HistoricoComponent,
    ImagensComponent,
    LaboratorioComponent,
    ProcedimentosComponent,
    ReceituarioComponent
    ]
})

export class AdminLayoutModule { }
