import { NgModule } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import intetactionPlugin from '@fullcalendar/interaction'
import { EventInput } from '@fullcalendar/core';
import { AgendarConsultaComponent } from "./agendar-consulta/agendar-consulta.component";

import { 
  MatDialog,
  MatDialogRef, 
  MAT_DIALOG_DATA,
} from '@angular/material';


@Component({
  selector: 'app-agenda',
  templateUrl: './agenda.component.html',
  styleUrls: ['./agenda.component.scss']
})

export class AgendaComponent {

  calendarVisible = true;
  calendarWeekends = true;

  calendarPlugins = [dayGridPlugin, timeGridPlugin, listPlugin, intetactionPlugin]; // Variavel para carregar os pluggins

  calendarHeader = { //Define a localização dos butões e o titulo no cabeçalho do calendário
    left: 'prev,next today',
    center: 'title',
    right: 'dayGridMonth,timeGridWeek,timeGridDay'
  }

  calendarButtonText = { //Define o texto que aparece no cabeçalho do calendário
    today:    'Hoje',
    month:    'Mês',
    week:     'Semana',
    day:      'Dia',
    list:     'Lista'    
  }

  calendarEvents: EventInput[] = [
    { title: 'Event Now', start: new Date() }
  ];

  handleDateClick(arg) {
    console.log(arg.date)
    const dialogRef = this.dialog.open(AgendarConsultaComponent,{
      width: '640px',disableClose: false
    });
  

    // if (confirm('Would you like to add an event to ' + arg.dateStr + ' ?')) {
    //   this.calendarEvents = this.calendarEvents.concat({ // add new event data. must create new array
    //     title: 'New Event',
    //     start: arg.date,
    //     allDay: arg.allDay
    //   })
    // }
  }

  constructor(public dialog: MatDialog) {  
    
  }

  ngOnInit() {
    
  }


}