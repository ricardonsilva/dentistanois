import { Classe_Paciente } from "./classe_paciente";

export const PACIENTES: Classe_Paciente[] = [
    {prontuario: 1, name: 'Joselito Contoso', telefone: 15998584100, email: 'joselito@gmail.com'},
    {prontuario: 2, name: 'Patati', telefone: 4.0026, email: 'He'},
    {prontuario: 3, name: 'Lithium', telefone: 6.941, email: 'Li'},
    {prontuario: 4, name: 'Beryllium', telefone: 9.0122, email: 'Be'},
    {prontuario: 5, name: 'Boron', telefone: 10.811, email: 'B'},
    {prontuario: 6, name: 'Carbon', telefone: 12.0107, email: 'C'},
    {prontuario: 7, name: 'Nitrogen', telefone: 14.0067, email: 'N'},
    {prontuario: 8, name: 'Oxygen', telefone: 15.9994, email: 'O'},
    {prontuario: 9, name: 'Fluorine', telefone: 18.9984, email: 'F'},
    {prontuario: 10, name: 'Neon', telefone: 20.1797, email: 'Ne'},
    {prontuario: 1, name: 'Hydrogen', telefone: 1.0079, email: 'H'},
    {prontuario: 2, name: 'Helium', telefone: 4.0026, email: 'He'},
    {prontuario: 3, name: 'Lithium', telefone: 6.941, email: 'Li'},
    {prontuario: 4, name: 'Beryllium', telefone: 9.0122, email: 'Be'},
    {prontuario: 5, name: 'Boron', telefone: 10.811, email: 'B'},
    {prontuario: 6, name: 'Carbon', telefone: 12.0107, email: 'C'},
    {prontuario: 7, name: 'Nitrogen', telefone: 14.0067, email: 'N'},
    {prontuario: 8, name: 'Oxygen', telefone: 15.9994, email: 'O'},
    {prontuario: 9, name: 'Fluorine', telefone: 18.9984, email: 'F'},
    {prontuario: 10, name: 'Neon', telefone: 20.1797, email: 'Ne'},
  ];