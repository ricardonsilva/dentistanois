export const API_CONFIG = {
    baseUrl: 'http://localhost:8080/api'
};
