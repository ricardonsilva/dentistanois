export const STORAGE_KEYS = {
    oauth: 'oauth',
    usuario: 'usuario'
};
