import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { CadastroPacienteComponent } from "../pacientes/cadastro-paciente/cadastro-paciente.component";
import { AgendarConsultaComponent } from "../agenda/agendar-consulta/agendar-consulta.component";
import { ProntuarioComponent } from "../pacientes/prontuario/prontuario.component";
import { Classe_Paciente } from "../classe_paciente";
import { PACIENTES } from "../lista_pacientes";

import {
  MatDialog
} from '@angular/material';

@Component({
  selector: 'app-pacientes',
  templateUrl: './pacientes.component.html',
  styleUrls: ['./pacientes.component.scss']
})
export class PacientesComponent implements OnInit {
  
  DADOS_PACIENTES = PACIENTES;
  paciente_selecionado: Classe_Paciente;

  displayedColumns: string[] = ['prontuario', 'name', 'telefone', 'email', 'action'];
  dataSource = new MatTableDataSource<Classe_Paciente>(this.DADOS_PACIENTES);

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(public dialog: MatDialog) { }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(CadastroPacienteComponent, {
      width: '640px',
      disableClose: true
    });
  }

  abrir_agenda(): void {
    const dialogRef = this.dialog.open(AgendarConsultaComponent, {
      width: '640px', disableClose: false
    });
  }

  abrir_prontuario(paciente: Classe_Paciente): void {
    this.paciente_selecionado = paciente; 
    const dialogRef = this.dialog.open(ProntuarioComponent, {
      height: '80%',
      disableClose: true,
      data: {
        paciente: this.paciente_selecionado
      }
    });
  }

  /* onSelect(paciente: Classe_Paciente): void {  
    this.paciente_selecionado = paciente;
    console.log(this.paciente_selecionado);
  } */
}
