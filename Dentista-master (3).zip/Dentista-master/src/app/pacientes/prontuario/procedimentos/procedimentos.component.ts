import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-procedimentos',
  templateUrl: './procedimentos.component.html',
  styleUrls: ['./procedimentos.component.scss']
})
export class ProcedimentosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
