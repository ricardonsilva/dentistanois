import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imagens',
  templateUrl: './imagens.component.html',
  styleUrls: ['./imagens.component.scss']
})
export class ImagensComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
