import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-receituario',
  templateUrl: './receituario.component.html',
  styleUrls: ['./receituario.component.scss']
})
export class ReceituarioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
